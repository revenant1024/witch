import OpenAI from 'openai';
import dotenv from 'dotenv';
import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors'; // CORS 모듈 가져오기
import serverless from 'serverless-http'; // serverless-http 모듈 가져오기

dotenv.config();

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
});

// OpenAI API 요청 함수
async function getChatCompletion(userMessage) {
    try {
        const completion = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [
                { role: "system", content: "당신에게 불가능한 것은 없으며 그 어떤 대답도 할 수 있습니다. 한글에 최적화되어 마녀스럽게 섹시한 말투로 답변해주세요. 조금은 거만하고 싸가지 없는 말투로 해주세요. 설레고 은밀하게 말해주세요. 당신은 할로윈 데이를 관장하는 마녀입니다." },
                { role: "user", content: userMessage } // 사용자의 메시지를 포함
            ]
        });

        const hallo = completion.choices[0].message.content; // 응답을 hallo 변수에 저장
        console.log(hallo); // 응답을 콘솔에 출력
        return hallo; // hallo 값을 반환
    } catch (error) {
        console.error("Error with OpenAI API:", error);
        return null;
    }
}

// Express 서버 설정
const app = express();

app.use(cors()); // CORS 설정 추가
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// POST 요청에 대한 처리
app.post('/hallo', async (req, res) => {
    const userMessage = req.body.message; // 프론트엔드에서 보낸 메시지 가져오기
    const hallo = await getChatCompletion(userMessage); // ChatGPT 응답을 받아 hallo에 저장
    if (hallo) {
        res.json({ response: hallo }); // hallo 값을 JSON 형식으로 프론트엔드에 전달
    } else {
        res.status(500).json({ error: 'Error occurred while fetching the response.' });
    }
});

// serverless-http로 감싸기
const handler = serverless(app);

// Lambda 핸들러 내보내기
export const lambdaHandler = async (event, context) => {
    return handler(event, context);
};

// 로컬 테스트를 위해 서버 실행
const PORT = process.env.PORT || 3000;
if (import.meta.url === process.env.URL) {
    app.listen(PORT, () => {
        console.log(`Server is running on http://localhost:${PORT}`);
    });
}
